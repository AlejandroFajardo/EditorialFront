import { Component, OnInit } from '@angular/core';
import { ApplicationService } from 'src/app/shared/service/application.service';
import { ApplicationDTO } from 'src/app/shared/application.dto';

@Component({
  selector: 'app-profesor-dashboard',
  templateUrl: './profesor-dashboard.component.html',
  styleUrls: ['./profesor-dashboard.component.scss']
})
export class ProfesorDashboardComponent implements OnInit {
  applications: ApplicationDTO[] = [];
  filteredApplications: ApplicationDTO[] = [];
  selectedApplicationId?: number;

  filtroTitulo: string = '';
  filtroIsbn: string = '';
  filtroAnio: string = '';
  estadoSeleccionado: string = 'ALL';
  isLoading = false;

  estados = [
    { label: 'Todas', value: 'ALL' },
    { label: 'Radicada', value: 'RADICADA' },
    { label: 'Devuelta centro', value: 'DEVUELTA_CENTRO' },
    { label: 'Aprobada centro', value: 'APROBADA_CENTRO' },
    { label: 'Rechazada centro', value: 'RECHAZADA_CENTRO' },
    { label: 'Devuelta jefe', value: 'DEVUELTA_JEFE' },
    { label: 'Aprobada jefe', value: 'APROBADA_JEFE' },
    { label: 'Rechazada jefe', value: 'RECHAZADA_JEFE' },
    { label: 'Devuelta editorial', value: 'DEVUELTA_EDITORIAL' },
    { label: 'Aprobada editorial', value: 'APROBADA_EDITORIAL' },
    { label: 'Rechazada editorial', value: 'RECHAZADA_EDITORIAL' }
  ];

  constructor(private applicationService: ApplicationService) {}

  ngOnInit(): void {
    this.isLoading = true;
    this.applicationService.getMyApplications().subscribe({
      next: apps => {
        this.applications = apps;
        this.filtrarAplicaciones();
        this.isLoading = false;
      },
      error: err => {
        this.isLoading = false;
        console.error('Error cargando aplicaciones', err);
      }
    });
  }

  filtrarAplicaciones(): void {
    let apps = this.applications;

    if (this.estadoSeleccionado !== 'ALL') {
      apps = apps.filter(app => app.status === this.estadoSeleccionado);
    }
    if (this.filtroTitulo.trim()) {
      apps = apps.filter(app => (app.bookTitle || '').toLowerCase().includes(this.filtroTitulo.trim().toLowerCase()));
    }
    if (this.filtroIsbn.trim()) {
      apps = apps.filter(app => (app.isbnCode || '').toLowerCase().includes(this.filtroIsbn.trim().toLowerCase()));
    }
    if (this.filtroAnio.trim()) {
      apps = apps.filter(app => (app.publicationYear ? app.publicationYear.toString() : '').includes(this.filtroAnio.trim()));
    }

    this.filteredApplications = apps.sort(
      (a, b) => new Date(b.createdAt ?? '').getTime() - new Date(a.createdAt ?? '').getTime()
    );
  }

  onEstadoChange(): void { this.filtrarAplicaciones(); }
  onFiltroTituloChange(): void { this.filtrarAplicaciones(); }
  onFiltroIsbnChange(): void { this.filtrarAplicaciones(); }
  onFiltroAnioChange(): void { this.filtrarAplicaciones(); }

  view(id: number): void {
    this.selectedApplicationId = id;
  }

  onModalClose(): void {
    this.selectedApplicationId = undefined;
    this.ngOnInit();
  }

  traducirEstado(estado: string): string {
    switch (estado) {
      case 'RADICADA': return 'Radicada';
      case 'DEVUELTA_CENTRO': return 'Devuelta por centro';
      case 'APROBADA_CENTRO': return 'Aprobada por centro';
      case 'RECHAZADA_CENTRO': return 'Rechazada por centro';
      case 'DEVUELTA_JEFE': return 'Devuelta por jefe';
      case 'APROBADA_JEFE': return 'Aprobada por jefe';
      case 'RECHAZADA_JEFE': return 'Rechazada por jefe';
      case 'DEVUELTA_EDITORIAL': return 'Devuelta por editorial';
      case 'APROBADA_EDITORIAL': return 'Aprobada por editorial';
      case 'RECHAZADA_EDITORIAL': return 'Rechazada por editorial';
      default: return estado ?? '-';
    }
  }
}
